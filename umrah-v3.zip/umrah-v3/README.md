# Umrah Guide PWA — دليل العمرة الشامل

A bilingual, fully offline Umrah guide designed for pilgrims.
Updated with Wake Lock Support and Automated Cloud Syncing!